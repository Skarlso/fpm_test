#!/usr/bin/env bash

echo "Hi from link"

source ./call-me.sh